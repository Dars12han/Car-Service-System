package com.gqt.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Customer {
	
	private String name;
	private String username;
	private String password;
	private String email;
	
	Connection con = null;
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", username=" + username + ", password=" + password + ", email=" + email
				+ "]";
	}

	public Customer(String name, String username, String password, String email) {
		super();
		this.name = name;
		this.username = username;			//p constr
		this.password = password;
		this.email = email;
	}
	
	public Customer() {
		super();				//non p-constr
	}


				//getter nd setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	{						//non-static
		try {
		DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/j","root","root");
			}
		catch(Exception e) {
				e.printStackTrace();
			}
	}

    public int getCustomers() {

		try {
			String s = "insert into customer values(?,?,?,?)";
			PreparedStatement psmt = con.prepareStatement(s);
			
			psmt.setString(1, name);
			psmt.setString(2, username);
			psmt.setString(3, password);
			psmt.setString(4, email);
			
			int rows = psmt.executeUpdate();
			return rows;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
    public int custLogin() {
    	
    	try {
    		String s1 = "select * from customer where username = ? ";
    		PreparedStatement psmt = con.prepareStatement(s1);
    		psmt.setString(1, username);
    		ResultSet res = psmt.executeQuery();
    		
    		if(res.next()) {
    			if(res.getString(3).equals(password)) {
    				name = res.getString(1);
    				return 1;
    			}
    			else 
    			{
    				return -1;
    			}
    		}
    		else 
    		{
    		return 0;
    		}
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    		
    	}
    	return 0;
    }
    public List<Customer> viewCustomers(){
    	try {
    		ArrayList<Customer> customerList = new ArrayList<>();
    		String s = "select * from customer";
    		Statement smt = con.createStatement();
    		
    		ResultSet res = smt.executeQuery(s);
    		while(res.next()) {
    			name = res.getString(1);
    			username = res.getString(2);
    			password = res.getString(3);
    			email = res.getString(4);
    			Customer c = new Customer(name, username, password, email);
    			customerList.add(c);
    		}
    		return customerList;
    		
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return null ;
    }



}
